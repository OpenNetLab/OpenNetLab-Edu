PacketId = int
FlowId   = int
ClassId  = int
Priority = int
