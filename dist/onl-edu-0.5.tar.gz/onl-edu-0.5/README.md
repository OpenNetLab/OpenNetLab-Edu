<h1 align="center">onl library</h1>

## Introduction

onl is a library which is built for network education. It can be regarded as a simplified version of ns3 which is written in python.
You can build up network expirements for education using this library.

For more details, see [this site](https://opennetlab.github.io/OpenNetLab-Edu-Doc/html/index.html)

## Installation

```
python3 -m pip install .
```
